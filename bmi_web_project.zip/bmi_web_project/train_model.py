# train_model.py

import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor  # Example model, use your best-performing model
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load the data
data = pd.read_csv("500_Person_Gender_Height_Weight_Index.csv")
# Preprocess data
data = pd.get_dummies(data, columns=['Gender'], drop_first=True)
X = data.drop('Index', axis=1)
y = data['Index']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Save the scaler
joblib.dump(scaler, 'model/scaler.pkl')

# Train the RandomForestRegressor model
best_model = RandomForestRegressor(n_estimators=100, random_state=101)
best_model.fit(X_train_scaled, y_train)

# Evaluate the model (optional)
y_pred = best_model.predict(X_test_scaled)
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Absolute Error: {mae:.4f}")
print(f"Mean Squared Error: {mse:.4f}")
print(f"R² Score: {r2:.4f}")

# Save the model
joblib.dump(best_model, 'model/bmi_model.pkl')

from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load the saved model and scaler
model = joblib.load('model/bmi_model.pkl')
scaler = joblib.load('model/scaler.pkl')

# Define BMI categories
bmi_category = ['Extremely Weak', 'Weak', 'Normal', 'OverWeight', 'Obesity', 'Extremely Obesity']

# Route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Route for the prediction
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        gender = request.form['gender']
        height = float(request.form['height'])
        weight = float(request.form['weight'])
        
        # Convert gender to numeric (choose one option as per the model you trained)
        gender_male = 1 if gender == 'Male' else 0
        # gender_female = 0 if gender == 'Male' else 1  # Uncomment if using both gender features

        # Prepare input features with the correct number of features (matching your training setup)
        input_features = np.array([[height, weight, gender_male]])
        
        # Scale input features
        input_features_scaled = scaler.transform(input_features)
        
        # Predict using the model
        prediction = model.predict(input_features_scaled)
        prediction_category = bmi_category[int(prediction[0])]
        
        return render_template('result.html', prediction=prediction_category)

if __name__ == '__main__':
    app.run(debug=True)
